require: sc/addNote.sc
require: sc/deleteNote.sc

theme: /
    state: Welcome
        q!: * (запусти|открой) (запись|трекер) *
        intent!: /start
        event!: RUN_APP
        a: Привет! Я твой трекер настроения.
    state: CatchAll
        q!: *
        a: Я тебя слышу, но не понимаю команду. Ты сказал: {{$request.query}}