theme: /
    state: DeleteMood
        q!: * (~удали*|~стереть) *
        script:
            $response.replies = $response.replies || [];
            $response.replies.push({
                "type": "raw",
                "body": {
                    "items": [
                        {
                            "command": {
                                "type": "smart_app_data",
                                "smart_app_data": { 
                                    "type": "REMOVE_LAST_MOOD" 
                                }
                            }
                        }
                    ]
                }
            });
        a: Без проблем, удалил последнее. 