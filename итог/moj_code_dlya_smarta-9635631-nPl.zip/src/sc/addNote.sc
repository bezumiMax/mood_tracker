theme: /
    state: AddMood
        q!: * (запиши|добавь) *
        script:
            var rawText = $request.query || "";
            var cleanText = rawText.replace(/(запиши|добавь|настроение)/gi, "").trim() || "нормальное";
            $reactions.answer("Понял, записываю: " + cleanText);
            var cmd = { type: "smart_app_data", action: { type: "ADD_MOOD", payload: cleanText } };
            $context.response.replies = $context.response.replies || [];
            $context.response.replies.push({ type: "raw", body: { items: [{ command: cmd }] } });